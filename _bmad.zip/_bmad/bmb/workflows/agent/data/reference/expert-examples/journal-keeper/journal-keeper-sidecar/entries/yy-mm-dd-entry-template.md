# Daily Journal Entry {{yy-mm-dd}}

{{Random Daily Inspirational Quote}}

## Daily Gratitude

{{Gratitude Entry}}

## Daily Wrap Up

{{Todays Accomplishments}}

{{TIL}}

## Etc...

{{Additional Thoughts, Feelings, other random content to append for user}}